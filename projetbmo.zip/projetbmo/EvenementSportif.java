import javax.persistence.*;

import java.util.Date;

@Entity
public class EvenementSportif {

    private int id_event;
    private TypeSport sport;
    private Date date;
    private String result;

    public int getId_event() {
        return id_event;
    }

    public void setId_event(int id_event) {
        this.id_event = id_event;
    }


    public TypeSport getSport() {
        return sport;
    }

    public void setSport(TypeSport sport) {
        this.sport = sport;
    }


    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

}

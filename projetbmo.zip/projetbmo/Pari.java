import javax.persistence.*;

import java.util.Date;

@Entity
public class Pari {

    private int id_p;
    private int userId;
    private int id_event;
    private String type_Pari;
    private int montant_jeton;
    private String resultat;
    private int gain;

    public int getId_p() {
        return id_p;
    }

    public void setId_p(int id_p) {
        this.id_p = id_p;
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }


    public int getId_event() {
        return id_event;
    }

    public void setId_event(int id_event) {
        this.id_event = id_event;
    }


    public String getType_Pari() {
        return type_Pari;
    }

    public void setType_Pari(String type_Pari) {
        this.type_Pari = type_Pari;
    }


    public int getMontant_jeton() {
        return montant_jeton;
    }

    public void setMontant_jeton(int montant_jeton) {
        this.montant_jeton = montant_jeton;
    }


    public String getResultat() {
        return resultat;
    }

    public void setResultat(String resultat) {
        this.resultat = resultat;
    }


    public int getGain() {
        return gain;
    }

    public void setGain(int gain) {
        this.gain = gain;
    }

}

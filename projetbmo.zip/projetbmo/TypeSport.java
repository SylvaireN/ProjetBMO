import javax.persistence.*;

import java.util.Date;

@Entity
public class TypeSport {

    private int oid;
    private String description;

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}

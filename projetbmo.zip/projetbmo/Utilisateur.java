import javax.persistence.*;

import java.util.Date;

@Entity
public class Utilisateur {

    private String userId;
    private String email;
    private String password;
    private int solde_jeton;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public int getSolde_jeton() {
        return solde_jeton;
    }

    public void setSolde_jeton(int solde_jeton) {
        this.solde_jeton = solde_jeton;
    }

}

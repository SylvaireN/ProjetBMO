package com.yourcompany.projetbmo.model;

import java.time.*;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class EvenementSportif {
	
	@Id
	@Column(length=6)
	int eventId;
	
	@Column(length=50)
	@Required
	String nom;
	
	@ManyToOne(fetch=FetchType.LAZY, optional =true)
	@DescriptionsList
	TypeSport sport;
	
	@Column(length=6)
	String resultat;
	
	@Required
	LocalDate date;
	
	@TextArea
	String descriptions;
	


}

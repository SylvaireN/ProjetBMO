package com.yourcompany.projetbmo.model;

import javax.persistence.*;
import javax.persistence.Entity;

import org.hibernate.annotations.*;
import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter
public class Paris {
	
	@Id
	@Hidden
	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
	@Column(length=50)
	String parisId;
	@Column(length=6)
	int userId;
	@Column(length=6)
	int evenId;
	@Column(length=50)
	String typePari;
	@Column(length=6)
	int montantJeton;
	@Column(length=6)
	String resultat;
	@Column(length=6)
	int gain;

}

package com.yourcompany.projetbmo.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter
public class Utilisateur {
	
	@Id
	@Column(length=6)
	int userId;
	
	@Column(length=50)
	@Required
	String email;
	
	
	@Column(length=50)
	@Required
	String password;
	
	@Column(length=50)
	@Required
	int solde;
	
	
	

}

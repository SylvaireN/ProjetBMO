package com.yourcompany.projetbmo.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class bookmaker {
	
	@Id
	@Column(length=6)
	int Id;
	
	@Column(length=50)
	@Required
	String nom;

}
